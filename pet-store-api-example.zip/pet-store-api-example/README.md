# Pet Store API

## Recompile and run API

`./mvnw compile quarkus:dev`

## Tech

* Quarkus
* smallrye-jwt
* REST API
* liquibase
* postgresql as db
* OpenAPI Generator
* Maven

