package com.inventage.pet_store_api.api;

import org.eclipse.microprofile.jwt.Claims;
import io.smallrye.jwt.build.Jwt;

import java.util.HashSet;
import java.util.Arrays;

public class GenerateToken {
    public static void main(String[] args) {
        // We're using smallrye-jwt for our pet store api and need some JWTs to authenticate.
        // Normally we'd have to use something keycloak or ory but that is overkill
        // for our sample app.
        String token =
                Jwt.issuer("https://example.com/issuer")
                        .upn("jdoe@quarkus.io")
                        .groups(new HashSet<>(Arrays.asList("User", "Admin")))
                        .claim(Claims.birthdate.name(), "2001-07-13")
                        .sign();
        // Output format:
        // The JWT string is the Base64 URL encoded string that has 3 parts separated by '.' characters.
        // First part - JWT headers, second part - JWT claims, third part - JWT signature.
        System.out.println(token);
    }
}
