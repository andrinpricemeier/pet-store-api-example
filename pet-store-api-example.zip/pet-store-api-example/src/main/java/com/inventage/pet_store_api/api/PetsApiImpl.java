package com.inventage.pet_store_api.api;

import com.inventage.pet_store_api.api.model.Pet;
import jakarta.annotation.security.RolesAllowed;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.SecurityContext;
import org.eclipse.microprofile.jwt.JsonWebToken;

@RequestScoped
public final class PetsApiImpl implements PetsApi {
    @Inject
    JsonWebToken jwt;

    @Context
    SecurityContext ctx;

    @Override
    @RolesAllowed({ "User", "Admin" })
    public Pet getPets() {
        final var result = getResponseString() + ", birthdate: " + jwt.getClaim("birthdate").toString();
        final var pet = new Pet();
        pet.setDescription(result);
        return pet;
    }

    private String getResponseString() {
        String name = "";
        if (ctx.getUserPrincipal() == null) {
            name = "anonymous";
        } else if (!ctx.getUserPrincipal().getName().equals(jwt.getName())) {
            // throw new InternalServerErrorException("Principal and JsonWebToken names do not match");
        } else {
            name = ctx.getUserPrincipal().getName();
        }
        return String.format("hello + %s,"
                        + " isHttps: %s,"
                        + " authScheme: %s,"
                        + " hasJWT: %s",
                name, ctx.isSecure(), ctx.getAuthenticationScheme(), hasJwt());
    }

    private boolean hasJwt() {
        return jwt.getClaimNames() != null;
    }
}