package com.inventage.pet_store_api.api;

import com.inventage.pet_store_api.api.model.Pet;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Response;

import io.swagger.annotations.*;

import java.io.InputStream;
import java.util.Map;
import java.util.List;
import jakarta.validation.constraints.*;
import jakarta.validation.Valid;

@Path("/pets")
@Api(description = "the Pets API")
@jakarta.annotation.Generated(value = "org.openapitools.codegen.languages.JavaJAXRSSpecServerCodegen")
public interface PetsApi {

    @GET
    @Produces({ "application/json" })
    @ApiOperation(value = "Get the pets.", notes = "", authorizations = {
        
        @Authorization(value = "bearerAuth")
         }, tags={ "pets" })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Pets could be retrieved successfully", response = Pet.class) })
    Pet getPets();
}
