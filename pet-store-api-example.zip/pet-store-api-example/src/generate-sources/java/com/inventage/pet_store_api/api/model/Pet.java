package com.inventage.pet_store_api.api.model;

import com.inventage.pet_store_api.api.model.PetStatus;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import jakarta.validation.constraints.*;
import jakarta.validation.Valid;

import io.swagger.annotations.*;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonTypeName;

/**
 * The request for uploading a form document to the temp doc store.
 **/
@ApiModel(description = "The request for uploading a form document to the temp doc store.")
@JsonTypeName("Pet")
@jakarta.annotation.Generated(value = "org.openapitools.codegen.languages.JavaJAXRSSpecServerCodegen")
public class Pet   {
  private @Valid Integer petId;
  private @Valid String description;
  private @Valid Integer petCategoryId;
  private @Valid Integer vendorId;
  private @Valid byte[] petImages;
  private @Valid PetStatus petStatus;
  private @Valid Integer userId;

  /**
   **/
  public Pet petId(Integer petId) {
    this.petId = petId;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("petId")
  public Integer getPetId() {
    return petId;
  }

  @JsonProperty("petId")
  public void setPetId(Integer petId) {
    this.petId = petId;
  }

  /**
   **/
  public Pet description(String description) {
    this.description = description;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }

  @JsonProperty("description")
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   **/
  public Pet petCategoryId(Integer petCategoryId) {
    this.petCategoryId = petCategoryId;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("petCategoryId")
  public Integer getPetCategoryId() {
    return petCategoryId;
  }

  @JsonProperty("petCategoryId")
  public void setPetCategoryId(Integer petCategoryId) {
    this.petCategoryId = petCategoryId;
  }

  /**
   **/
  public Pet vendorId(Integer vendorId) {
    this.vendorId = vendorId;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("vendorId")
  public Integer getVendorId() {
    return vendorId;
  }

  @JsonProperty("vendorId")
  public void setVendorId(Integer vendorId) {
    this.vendorId = vendorId;
  }

  /**
   **/
  public Pet petImages(byte[] petImages) {
    this.petImages = petImages;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("petImages")
  public byte[] getPetImages() {
    return petImages;
  }

  @JsonProperty("petImages")
  public void setPetImages(byte[] petImages) {
    this.petImages = petImages;
  }

  /**
   **/
  public Pet petStatus(PetStatus petStatus) {
    this.petStatus = petStatus;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("petStatus")
  public PetStatus getPetStatus() {
    return petStatus;
  }

  @JsonProperty("petStatus")
  public void setPetStatus(PetStatus petStatus) {
    this.petStatus = petStatus;
  }

  /**
   **/
  public Pet userId(Integer userId) {
    this.userId = userId;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("userId")
  public Integer getUserId() {
    return userId;
  }

  @JsonProperty("userId")
  public void setUserId(Integer userId) {
    this.userId = userId;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Pet pet = (Pet) o;
    return Objects.equals(this.petId, pet.petId) &&
        Objects.equals(this.description, pet.description) &&
        Objects.equals(this.petCategoryId, pet.petCategoryId) &&
        Objects.equals(this.vendorId, pet.vendorId) &&
        Objects.equals(this.petImages, pet.petImages) &&
        Objects.equals(this.petStatus, pet.petStatus) &&
        Objects.equals(this.userId, pet.userId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(petId, description, petCategoryId, vendorId, petImages, petStatus, userId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Pet {\n");
    
    sb.append("    petId: ").append(toIndentedString(petId)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    petCategoryId: ").append(toIndentedString(petCategoryId)).append("\n");
    sb.append("    vendorId: ").append(toIndentedString(vendorId)).append("\n");
    sb.append("    petImages: ").append(toIndentedString(petImages)).append("\n");
    sb.append("    petStatus: ").append(toIndentedString(petStatus)).append("\n");
    sb.append("    userId: ").append(toIndentedString(userId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }


}

